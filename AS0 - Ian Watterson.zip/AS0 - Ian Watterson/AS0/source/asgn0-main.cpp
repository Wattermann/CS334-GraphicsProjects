/**
 Department of Computer Science
 Purdue University
 August 28, 2013
 CS334 Assignment #0 Warm-up Assignment
 Ian Watterson
 **/
#include <G3D/G3DAll.h>
#include <GLG3D/GLG3D.h>
#include <time.h>

////////////
// Define necessary globals here
// *** add code ***
////////////

float x00;
float y00;
float x01;
float y01;
float vX0;
float vY0;
float vX1;
float vY1;
G3D_START_AT_MAIN();

float outOfBounds(float questionable, float vel);
void drawFrame(int w, int h) {

	// Set up the camera and window space; here spans (-10, -10) to (+10, +10)
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-10.0f, 10.0f, -10.0f, 10.0f);
	
    glClearColor(0.0f, 0.2f, 0.4f, 1.0f);
    glClearDepth(1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDisable(GL_LIGHTING);
	
    // Move the line in camera space
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	///////////////
	// *** add code below ***


	// update position of two 2D points
	x00+= vX0;
	y00+= vY0;
	x01+= vX1;
	y01+= vY1;

	// bounce points off the edge of the window
	// if the point is over the boundry, change the velocity's direction and reapply it
	if(x00 > 10 || x00 < -10) {
		vX0*= -1;
		x00+= vX0;
	}
	if(y00 > 10 || y00 < -10) {
		vY0*= -1;
		y00+= vY0;
	}
	if(x01 > 10 || x01 < -10) {
		vX1*= -1;
		x01+= vX1;
	}
	if(y01 > 10 || y01 < -10) {
		vY1*= -1;
		y01+= vY1;
	}
	glLineWidth(3);
	glColor3f(1,0,0);
	// draw a line using GL_LINES
	
	// *** add code above ***
	///////////////

	
	glBegin(GL_LINES);
	glVertex2f(x00,y00);
	glVertex2f(x01,y01);
	glEnd();
}

int main(int argc, char** argv) {
    RenderDevice* rd = new RenderDevice();
    OSWindow::Settings settings;

    settings.width = 960;
    settings.height = 600;

    rd->init(settings);

	srand(time(0));
	x00 = rand() % 10;
	y00 = rand() % 10;
	x01 = rand() % 10;
	y01 = rand() % 10;

	//make sure the velocity is not zero
	vX0 = ((rand() % 100)+1)/40;
	while((int)vX0 == 0) {
		vX0 = ((rand() % 100)+1)/40;
	}
	vY0 = ((rand() % 100)+1)/40;
	while((int)vY0 == 0) {
		vY0 = ((rand() % 100)+1)/40;
	}
	vX1 = ((rand() % 100)+1)/40;
	while((int)vX1 == 0) {
		vX1 = ((rand() % 100)+1)/40;
	}
	vY1 = ((rand() % 100)+1)/40;
	while((int)vY1 == 0) {
		vY1 = ((rand() % 100)+1)/40;
	}

	////////////
	// compute random initial position and velocity of two 2D points within the application window
	// ** add code here ***
	///////////

 	for (int i=0; i<300; i++) {

		// draw frame
        drawFrame(settings.width, settings.height);

        // Render at 30 fps
        System::sleep(1.0/30.0);

        // See also RenderDevice::beginFrame, RenderDevice::endFrame
        rd->swapBuffers();
    }

    rd->cleanup();
    delete rd;

    return 0;
}