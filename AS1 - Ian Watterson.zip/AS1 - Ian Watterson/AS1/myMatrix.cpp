//myMatrix.cpp
#include <myMatrix.h>
#include <math.h>

myMatrix transposeMatrix(myMatrix m){
	myMatrix transMatrix = myMatrix();
	transMatrix[0] = m[0];
	transMatrix[1] = m[4];
	transMatrix[2] = m[8];
	transMatrix[3] =m[12];
	transMatrix[4] = m[1];
	transMatrix[5] = m[5];
	transMatrix[6] = m[9];
	transMatrix[7] =m[13];
	transMatrix[8] = m[2];
	transMatrix[9] = m[6];
	transMatrix[10]=m[10];
	transMatrix[11]=m[14];
	transMatrix[12]= m[3];
	transMatrix[13]= m[7];
	transMatrix[14]=m[11];
	transMatrix[15]=m[15];
	return transMatrix;
};

myVector myMatrix::matrixByVector(myMatrix m, myVector v){
	myVector resultVector = myVector();
	float x0 = (m[0]*v[0]) + (m[1]*v[1]) + (m[2]*v[2]) + (m[3]*v[3]);
	float y0 = (m[4]*v[0]) + (m[5]*v[1]) + (m[6]*v[2]) + (m[7]*v[3]);
	float z0 = (m[8]*v[0]) + (m[9]*v[1]) + (m[10]*v[2])+(m[11]*v[3]);
	float w0 = (m[12]*v[0])+ (m[13]*v[1])+ (m[14]*v[2])+(m[15]*v[3]);
	float homogeneous = w0;
	if(homogeneous!=0 && homogeneous!=1) {
		resultVector[0] = x0/homogeneous;
		resultVector[1] = y0/homogeneous;
		resultVector[2] = z0/homogeneous;
		resultVector[3] = w0/homogeneous;
	}
	else{
		resultVector[0] = x0;
		resultVector[1] = y0;
		resultVector[2] = z0;
		resultVector[3] = w0;
	}
	return resultVector;
};

myPoint myMatrix::matrixByPoint(myMatrix m, myPoint p){
	myPoint resultPoint = myPoint();
	float x0 = (m[0]*p[0]) + (m[1]*p[1]) + (m[2]*p[2]) + (m[3]*p[3]);
	float y0 = (m[4]*p[0]) + (m[5]*p[1]) + (m[6]*p[2]) + (m[7]*p[3]);
	float z0 = (m[8]*p[0]) + (m[9]*p[1]) + (m[10]*p[2])+(m[11]*p[3]);
	float w0 = (m[12]*p[0])+ (m[13]*p[1])+ (m[14]*p[2])+(m[15]*p[3]);
	float homogeneous = w0;
	if(homogeneous!=0 && homogeneous!=1) {
		resultPoint[0] = x0/homogeneous;
		resultPoint[1] = y0/homogeneous;
		resultPoint[2] = z0/homogeneous;
		resultPoint[3] = w0/homogeneous;
	}
	else{
		resultPoint[0] = x0;
		resultPoint[1] = y0;
		resultPoint[2] = z0;
		resultPoint[3] = w0;
	}
	return resultPoint;
};

myMatrix myMatrix::matrixByMatrix(myMatrix m1, myMatrix m2){
	myMatrix resultMatrix = myMatrix();
	resultMatrix[0] = (m1[0]*m2[0]) + (m1[1]*m2[4]) + (m1[2]*m2[8]) + (m1[3]*m2[12]);
	resultMatrix[1] = (m1[0]*m2[1]) + (m1[1]*m2[5]) + (m1[2]*m2[9]) + (m1[3]*m2[13]);
	resultMatrix[2] = (m1[0]*m2[2]) + (m1[1]*m2[6]) + (m1[2]*m2[10])+ (m1[3]*m2[14]);
	resultMatrix[3] = (m1[0]*m2[3]) + (m1[1]*m2[7]) + (m1[2]*m2[11])+ (m1[3]*m2[15]);
	resultMatrix[4] = (m1[4]*m2[0]) + (m1[5]*m2[4]) + (m1[6]*m2[8]) + (m1[7]*m2[12]);
	resultMatrix[5] = (m1[4]*m2[1]) + (m1[5]*m2[5]) + (m1[6]*m2[9]) + (m1[7]*m2[13]);
	resultMatrix[6] = (m1[4]*m2[2]) + (m1[5]*m2[6]) + (m1[6]*m2[10])+ (m1[7]*m2[14]);
	resultMatrix[7] = (m1[4]*m2[3]) + (m1[5]*m2[7]) + (m1[6]*m2[11])+ (m1[7]*m2[15]);
	resultMatrix[8] = (m1[8]*m2[0]) + (m1[9]*m2[4]) + (m1[10]*m2[8])+(m1[11]*m2[12]);
	resultMatrix[9] = (m1[8]*m2[1]) + (m1[9]*m2[5]) + (m1[10]*m2[9])+(m1[11]*m2[13]);
	resultMatrix[10] =(m1[8]*m2[2]) + (m1[9]*m2[6]) +(m1[10]*m2[10])+(m1[11]*m2[14]);
	resultMatrix[11] =(m1[8]*m2[3]) + (m1[9]*m2[7]) +(m1[10]*m2[11])+(m1[11]*m2[15]);
	resultMatrix[12]=(m1[12]*m2[0]) +(m1[13]*m2[4])+ (m1[14]*m2[8])+(m1[15]*m2[12]);
	resultMatrix[13]=(m1[12]*m2[1]) +(m1[13]*m2[5])+ (m1[14]*m2[9])+(m1[15]*m2[13]);
	resultMatrix[14]=(m1[12]*m2[2]) +(m1[13]*m2[6])+(m1[14]*m2[10])+(m1[15]*m2[14]);
	resultMatrix[15]=(m1[12]*m2[3]) +(m1[13]*m2[7])+(m1[14]*m2[11])+(m1[15]*m2[15]);
	return resultMatrix;
};

myMatrix myMatrix::uniformScaleMatrix(float scale){
	myMatrix scaleMatrix = myMatrix();
	scaleMatrix[0] = scale;
	scaleMatrix[5] = scale;
	scaleMatrix[10]= scale;
	return scaleMatrix;
};

myMatrix myMatrix::translationMatrix(float transX, float transY, float transZ){
	myMatrix translateMatrix = myMatrix();
	if(transX != 0)	translateMatrix[3] = transX;
	if(transY != 0)translateMatrix[7] = transY;
	if(transZ != 0)translateMatrix[11]= transZ;
	return translateMatrix;
};

myMatrix myMatrix::rotateAroundX(double r){
	myMatrix rotateX = myMatrix();
	rotateX[5] = cos(r);
	rotateX[6]= -sin(r);
	rotateX[9] = sin(r);
	rotateX[10]= cos(r);
	return rotateX;
};

myMatrix myMatrix::rotateAroundY(double r){
	myMatrix rotateY = myMatrix();
	rotateY[0] = cos(r);
	rotateY[2] =-sin(r);
	rotateY[8] = sin(r);
	rotateY[10]= cos(r);
	return rotateY;
};

myMatrix myMatrix::rotateAroundZ(double r){
	myMatrix rotateZ = myMatrix();
	rotateZ[0] = cos(r);
	rotateZ[1]= -sin(r);
	rotateZ[4] = sin(r);
	rotateZ[5] = cos(r);
	return rotateZ;
};

myMatrix myMatrix::perspective(float near){
	myMatrix perspective = myMatrix();
	perspective[0] = (2*near)/(20);
	perspective[2] = (0/20);
	perspective[5] = (2*near)/(20);
	perspective[6] = (0/20);
	perspective[10] = -(30+near)/(30-near);
	perspective[11] = (-2*45*near)/(30-near);
	perspective[14] = -1;
	perspective[15] = 0;
	return perspective;
};