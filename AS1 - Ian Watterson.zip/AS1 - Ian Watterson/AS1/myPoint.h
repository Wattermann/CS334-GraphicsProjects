//myPoint.h
#pragma once // Fixes this:  Error: PCH warning: header stop cannot be ina macro or #if block. An intellisence PCH file was not generated.

class myPoint{

	public:myPoint(){
		createdPoint[0] = 0;
		createdPoint[1] = 0;
		createdPoint[2] = 0;
		createdPoint[3] = 1;
	};
	public:myPoint(float vX, float vY, float vZ){
		createdPoint[0] = vX;
		createdPoint[1] = vY;
		createdPoint[2] = vZ;
		createdPoint[3] = 1;
	};
	public:myPoint(float vX, float vY, float vZ, float vW){
		createdPoint[0] = vX;
		createdPoint[1] = vY;
		createdPoint[2] = vZ;
		createdPoint[3] = vW;
	};

protected:
    float createdPoint[4];

public:
	//Read element
	float operator [](int i) const {return createdPoint[i];}
	//Write to element: dereferences the pointer to set the value
	float & operator [](int i) {return createdPoint[i];}
	//Additiom with another point using operator
	myPoint operator +(myPoint mP) const {return myPoint(createdPoint[0]+mP[0],
		createdPoint[1]+mP[1],createdPoint[2]+mP[2]);}
	//Subtraction with another point using operator
	myPoint operator -(myPoint mP) const {return myPoint(createdPoint[0]-mP[0],
		createdPoint[1]-mP[1],createdPoint[2]-mP[2]);}
};

//myPoint mP;
//mP.fun(2);