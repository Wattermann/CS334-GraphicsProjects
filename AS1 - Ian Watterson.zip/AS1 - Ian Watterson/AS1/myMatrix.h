//myMatrix.h
#pragma once // Fixes this:  Error: PCH warning: header stop cannot be ina macro or #if block. An intellisence PCH file was not generated.
#include <myVector.h>
#include <myPoint.h>

class myMatrix{
	public:myMatrix(){
		int i;
		for(i=0; i<16; i++){
			//Makes the matrix an Identity Matrix
			if(i%5 == 0) {
				createdMatrix[i] = 1;
			}
			else createdMatrix[i] = 0;
		}
	};
	public:myMatrix(float x0, float y0, float z0, float w0,
					float x1, float y1, float z1, float w1,
					float x2, float y2, float z2, float w2,
					float x3, float y3, float z3, float w3){

		createdMatrix[0] = x0; createdMatrix[1] = y0; createdMatrix[2] = z0; createdMatrix[3] = w0;
		createdMatrix[4] = x1; createdMatrix[5] = y1; createdMatrix[6] = z1; createdMatrix[7] = w1;
		createdMatrix[8] = x2; createdMatrix[9] = y2; createdMatrix[10]= z2; createdMatrix[11]= w2;
		createdMatrix[12]= x3; createdMatrix[13]= y3; createdMatrix[14]= z3; createdMatrix[15]= w3;
	};
		

protected:
    float createdMatrix[16];

public:
	//Read element
	float operator [](int i) const {return createdMatrix[i];}
	//Write to element: dereferences the pointer to set the value
	float & operator [](int i) {return createdMatrix[i];}
	myMatrix transposeMatrix(myMatrix m);
	myVector matrixByVector(myMatrix m, myVector v);
	myPoint matrixByPoint(myMatrix m, myPoint p);
	myMatrix matrixByMatrix(myMatrix m1, myMatrix m2);
	myMatrix identityMatrix(){return myMatrix();}
	myMatrix uniformScaleMatrix(float scale);
	myMatrix translationMatrix(float transX, float transY, float transZ);
	myMatrix rotateAroundX(double r);
	myMatrix rotateAroundY(double r);
	myMatrix rotateAroundZ(double r);
	myMatrix perspective(float near);
};

//myMatrix mM;
//mM.fun(2);