//myVector.h
#pragma once // Fixes this:  Error: PCH warning: header stop cannot be ina macro or #if block. An intellisence PCH file was not generated.

class myVector{

	public:myVector(){
		createdVector[0] = 0;
		createdVector[1] = 0;
		createdVector[2] = 0;
		createdVector[3] = 0;
	};
	public:myVector(float vX, float vY, float vZ){
		createdVector[0] = vX;
		createdVector[1] = vY;
		createdVector[2] = vZ;
		createdVector[3] = 0;
	};
	public:myVector(float vX, float vY, float vZ, float vW){
		createdVector[0] = vX;
		createdVector[1] = vY;
		createdVector[2] = vZ;
		createdVector[3] = vW;
	};

protected:
    float createdVector[4];

public:
	//Read element
	float operator [](int i) const {return createdVector[i];}
	//Write to element: dereferences the pointer to set the value
	float & operator [](int i) {return createdVector[i];}

	float vectorLength(myVector vec);
	float vectorDotProduct(myVector vec1, myVector vec2);
	myVector vectorCrossProduct(myVector vec1, myVector vec2);
	myVector normVector(myVector vec);
	//Multiplication with scalar using operator
	myVector operator *(float f) const {return myVector(f*createdVector[0],
		f*createdVector[1],f*createdVector[2]);}
	//Division with scalar using operator
	myVector operator /(float f) const {return myVector(createdVector[0]/f,
		createdVector[1]/f,createdVector[2]/f);}
	//Additiom with another vector using operator
	myVector operator +(myVector mV) const {return myVector(createdVector[0]+mV[0],
		createdVector[1]+mV[1],createdVector[2]+mV[2]);}
	//Subtraction with another vector using operator
	myVector operator -(myVector mV) const {return myVector(createdVector[0]-mV[0],
		createdVector[1]-mV[1],createdVector[2]-mV[2]);}
};

//myVector mV;
//mV.fun(2);