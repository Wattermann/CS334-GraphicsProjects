//myPoint.cpp
#include <myPoint.h>