//myVector.cpp
#include <myVector.h>
#include <math.h>

float myVector::vectorLength(myVector vec) {
	return sqrt((float)((vec[0]*vec[0]) + (vec[1]*vec[1]) + (vec[2]*vec[2])));
};

float myVector::vectorDotProduct(myVector vec1, myVector vec2){
	int theDot = 0;
	int i;
	for(i = 0; i < 3; i++) {
		theDot += (vec1[i]*vec2[i]);
	}
	return theDot;
};

myVector myVector::normVector(myVector vec) {
	float vecLen = vectorLength(vec);
	myVector normVec = myVector();
	int i;
	for(i = 0; i < 3; i++){
		normVec[i] = vec[i]/vecLen;
	}
	return normVec;
};

myVector myVector::vectorCrossProduct(myVector vec1, myVector vec2){
	myVector crossVec = myVector();
	crossVec[0] = ((vec1[1]*vec2[2])-(vec1[2]*vec2[1]));
	crossVec[1] =-((vec1[0]*vec2[2])-(vec1[2]*vec2[0]));
	crossVec[2] = ((vec1[0]*vec2[1])-(vec1[1]*vec2[0]));
	return crossVec;
};