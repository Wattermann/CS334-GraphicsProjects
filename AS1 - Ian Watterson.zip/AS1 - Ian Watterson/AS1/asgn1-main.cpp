/**
 Department of Computer Science
 Purdue University
 August 28, 2013
 CS334 Assignment #1 Linear Algebra
 Ian Watterson
 **/
#define _USE_MATH_DEFINES
#include <G3D/G3DAll.h>
#include <GLG3D/GLG3D.h>
#include <time.h>
#include <string>
#include <sstream>
#include <iostream>
#include <myVector.h>
#include <myPoint.h>
#include <myMatrix.h>

G3D_START_AT_MAIN();

////////////
// Define necessary globals here
// *** add code ***
////////////

int fPS = 30;
float speed = 1;

float x00;
float y00;
float z00;
float x01;
float y01;
float z01;

float vX0;
float vY0;
float vZ0;
float vX1;
float vY1;
float vZ1;

int r0Axis;
int r1Axis;
double randAngle0;
double randAngle1;
myMatrix rotate0;
myMatrix rotate1;

myPoint point0;
myPoint point1;

myVector vector0;
myVector vector1;

myMatrix translate0;
myMatrix translate1;

myVector mV;
myMatrix mM;
myPoint mP;

void print(float value) {
	std::wstringstream s;
	s << L"" <<value;
	std::wstring ws = s.str();
	OutputDebugString(ws.c_str());
}

void print(char* value) {
	std::wstringstream s;
	s << L"" <<value;
	std::wstring ws = s.str();
	OutputDebugString(ws.c_str());
}

void drawFrame(int w, int h) {

	// Set up the camera and window space; here spans (-10, -10, -10) to (+10, +10, +10)
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
	//3D for asgn1
    glOrtho(-10.0f, 10.0f, -10.0f, 10.0f, -10.0f, 10.0f);	
	
    glClearColor(0.0f, 0.2f, 0.4f, 1.0f);
    glClearDepth(1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDisable(GL_LIGHTING);
	
    // Move the line in camera space
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	///////////////
	// *** add code below ***
	
	if(r0Axis = 0) {
		rotate0 = mM.rotateAroundX(randAngle0);
	}
	else if(r0Axis = 1) {
		rotate0 = mM.rotateAroundY(randAngle0);
	}
	else if(r0Axis = 2) {
		rotate0 = mM.rotateAroundZ(randAngle0);
	}
	if(r1Axis = 0) {
		rotate1 = mM.rotateAroundX(randAngle1);
	}
	else if(r1Axis = 1) {
		rotate1 = mM.rotateAroundY(randAngle1);
	}
	else if(r1Axis = 2) {
		rotate1 = mM.rotateAroundZ(randAngle1);
	}

	vector0 = mM.matrixByVector(rotate0, vector0);
	vector1 = mM.matrixByVector(rotate1, vector1);

	translate0 = mM.translationMatrix(vector0[0], vector0[1], vector0[2]);
	translate1 = mM.translationMatrix(vector1[0], vector1[1], vector1[2]);
	
	// update position of two 3D points
	point0 = mM.matrixByPoint(translate0, point0);
	point1 = mM.matrixByPoint(translate1, point1);

	//myMatrix perspective = mM.perspective(10);

	//point0 = mM.matrixByPoint(perspective, point0);
	//point1 = mM.matrixByPoint(perspective, point1);

	// bounce points off the edge of the window
	// if the point is over the boundry, change the velocity's direction to apply it next time
	if(point0[0] > 10 || point0[0] < -10) vector0[0] = vector0[0]*(-1);		
	if(point0[1] > 10 || point0[1] < -10) vector0[1] = vector0[1]*(-1);
	if(point0[2] > 10 || point0[2] < -10) vector0[2] = vector0[2]*(-1);
	if(point1[0] > 10 || point1[0] < -10) vector1[0] = vector1[0]*(-1);		
	if(point1[1] > 10 || point1[1] < -10) vector1[1] = vector1[1]*(-1);
	if(point1[2] > 10 || point1[2] < -10) vector1[2] = vector1[2]*(-1);
	
	glLineWidth(3);
	glColor3f(1,1,1);
	// draw a line using GL_LINES
	
	// *** add code above ***
	///////////////

	
	glBegin(GL_LINES);
	// 3D for asgn1
	glVertex3f(point0[0],point0[1],point0[2]);
	glVertex3f(point1[0],point1[1],point1[2]);
	glEnd();
}

int main(int argc, char** argv) {

    RenderDevice* rd = new RenderDevice();
    OSWindow::Settings settings;

    settings.width = 960;
    settings.height = 600;

    rd->init(settings);

	srand(time(0));
	x00 = rand() % 10;
	y00 = rand() % 10;
	z00 = rand() % 10;
	x01 = rand() % 10;
	y01 = rand() % 10;
	z01 = rand() % 10;
	point0 = myPoint(x00,y00,z00);
	point1 = myPoint(x01,y01,z01);

	float LO = -10.0f;
	float HI = 10.0;
	float vX0 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));
	float vY0 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));
	float vZ0 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));
	float vX1 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));
	float vY1 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));
	float vZ1 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));

	/*
	print("\n");
	print(vX0);
	print("\n");
	print(vY0);
	print("\n");
	print(vZ0);
	print("\n");
	print(vX1);
	print("\n");
	print(vY1);
	print("\n");
	print(vZ1);
	print("\n");
	*/

	vector0 = mV.normVector(myVector(vX0,vY0,vZ0));
	vector1 = mV.normVector(myVector(vX1,vY1,vZ1));

	////////////
	// compute random initial position and velocity of two 2D points within the application window
	// ** add code here ***
	///////////

	vector0 = (vector0/fPS)*(speed*20);
	vector1 = (vector1/fPS)*(speed*20);

	LO = -((M_PI)/24);
	HI = (M_PI)/24;
	randAngle0 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));
	r0Axis = (rand()%3);
	randAngle1 = LO + (float)rand()/((float)RAND_MAX/(HI-LO));
	r1Axis = (rand()%3);
	/*
	print("\n");
	print(randAngle0);
	print("\n");
	print(r0Axis);
	print("\n");
	print(randAngle1);
	print("\n");
	print(r1Axis);
	print("\n");
	*/
 	for (int i=0; i<300; i++) {

		// draw frame
        drawFrame(settings.width, settings.height);

        // Render at 30 fps
        System::sleep(1.0/fPS);

        // See also RenderDevice::beginFrame, RenderDevice::endFrame
        rd->swapBuffers();
    }

    rd->cleanup();
    delete rd;

    return 0;
}